<?php
if (!file_exists("metadata.txt")) {
    echo "<p>No files uploaded yet.</p>";
    return;
}
$lines = file("metadata.txt");
foreach ($lines as $line) {
    list($filename, $language, $genre) = explode("|", trim($line));
    $filepath = "assets/$language/$genre/$filename";
    echo "<div>
        <p><strong>$filename</strong> [$language / $genre]</p>
        <audio controls src='$filepath'></audio><br>
        <a href='delete.php?filename=$filename&language=$language&genre=$genre'>Delete</a>
    </div><hr>";
}
?>