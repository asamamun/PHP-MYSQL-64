<?php
if(isset($a)){    
echo $a;
}
?>